import express from 'express'
import {globalAPIRouter} from "./APIRouters/__init__.js";


const PORT = 322
const app = express()
// app.use(express.static('./src/front/pages'));
// app.use(express.static('./src/front/public'));
// app.use(express.static('./gulpdist/pages'));
// app.use(express.static('./gulpdist/public'));
app.use(express.static('./dist'));


app.use('/api', globalAPIRouter)


app.listen(PORT, () => {console.log(`server start in http://localhost:${PORT}`)})
