import express from "express";
import {getUserById} from "../../services/users/getIUsernfo.js";


const router = express.Router()
router.use(express.json());

router.get('/:id([0-9]{1,})', (req, res) => {
    try {
        res.json(getUserById(req.params.id))
    } catch (e) {
        if (e.name === 'ValidationError') {
            res.json({'error': e.name, 'message': e.message})
            return
        }
        res.json({'error': 'something', 'message': 'some error'})
    }
})


export {router as getUserByIdRouter}
