import {Router} from "express";
import {usersRouter} from "./users/__init__.js";
import {statusesRouter} from "./statuses/__init__.js";


const router = Router()

router.use('/users', usersRouter)
router.use('/statuses', statusesRouter)


export {router as globalAPIRouter}