import {ValidationError} from "./errors.js";


export const validateUserId = (users, userId) => {

    if (!Number.isInteger(Number(userId))) {
        throw new ValidationError('userId isnt integer')
    }
    if (!users[userId.toString()]){
        throw new ValidationError('not found userId')
    }
}
